package edu.curso.aula1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class LerArquivoComFiltro {

	public static void main(String[] args) throws IOException {
		File f = new File("C:/teste.txt");
		
		FileReader fr = new FileReader( f );
		
		BufferedReader br = new BufferedReader( fr );
		
		String s = br.readLine();
		s = br.readLine();
		System.out.println( s );
		
		// Ler apenas a 1� linha
		
		br.close();

	}

}
