package edu.curso.aula2;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class Cliente {
	
	private Socket servidor;
	private InputStreamReader serverReader;
	private OutputStreamWriter serverWriter;

	public Cliente() { 
		try {
			System.out.println("Sistema - Cliente de Socket");
			servidor = new Socket("localhost", 20000);
			System.out.println("Cliente conectado");
			serverReader = new InputStreamReader(servidor.getInputStream());
			serverWriter = new OutputStreamWriter(servidor.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void executar() {
		InputStreamReader tecladoReader = new InputStreamReader(System.in);
		while(true) { 
			try {
				if (serverReader.ready()) { 
					char c = (char) serverReader.read();
					System.out.print(c);
				}
				if (tecladoReader.ready()) { 
					char c = (char) tecladoReader.read();
					serverWriter.write( c );
					serverWriter.flush();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		Cliente cli = new Cliente();
		cli.executar();

	}

}
