package edu.curso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LerArquivo {

	public static void main(String[] args) throws IOException {
		File f = new File("C:/teste.txt");
		
		System.out.println( "Arquivo existe ? " + f.exists() );
		System.out.println( "� um diret�rio ? " + f.isDirectory() );
		System.out.println( "Podemos Ler ? " + f.canRead() );
		System.out.println( "Podemos Gravar ? " + f.canWrite() );
		System.out.println( "\n\n");
		
		FileReader fr = new FileReader( f );
		
		int i = 0;
//		while ( i != -1) { 
//			i = fr.read();
//			if ( i != -1) {
//				System.out.print( (char)i );
//			}
//		}
		while( (i = fr.read()) != -1 ) { 
			System.out.print( (char) i);
		}
		fr.close();
	}

}
