package edu.curso;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

	public static void main(String[] args) throws IOException {
		System.out.println("Aplica��o Servidor iniciada");
		ServerSocket server = new ServerSocket( 20000 );
		System.out.println("Servidor iniciado e porta reservada, aguardando conex�o");
		Socket cliente = server.accept();
		System.out.println("Cliente conectado ... ");
		
		OutputStream out = cliente.getOutputStream();
		
		out.write( "Ola bem vindo ao servidor .... \n".getBytes()  );
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		System.out.println("Fim ...");
		server.close();
	}

}
