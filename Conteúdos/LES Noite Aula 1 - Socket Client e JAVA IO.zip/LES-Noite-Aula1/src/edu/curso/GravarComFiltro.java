package edu.curso;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class GravarComFiltro {

	public static void main(String[] args) throws IOException {
		File f = new File("C:/teste.txt");
		FileWriter fw = new FileWriter( f );
		
		BufferedWriter bw = new BufferedWriter( fw );
		bw.write("Texto 1", 2, 3);
		bw.append("\nTexto 2");
		bw.append("\nTexto 3");
		
		bw.flush();
		
		bw.close();
	
	}

}
